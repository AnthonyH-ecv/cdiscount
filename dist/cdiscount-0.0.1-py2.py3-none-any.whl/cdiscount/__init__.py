"""
Un package Python capable de relever le prix  de n'importe quel produit
du site www.cdiscount.com
"""