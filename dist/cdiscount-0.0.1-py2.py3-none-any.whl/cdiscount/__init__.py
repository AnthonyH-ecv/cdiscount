"""
A Python package able to show the price of any product
of the site www.cdiscount.com
"""